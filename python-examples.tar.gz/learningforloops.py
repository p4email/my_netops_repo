myitem1 = "Tacos"
myitem2 = "Racecars"
myitem3 = [myitem1, myitem2]

mylist = []
mylist.append(myitem1)
mylist.append(myitem2)
mylist.append(myitem3)

for item in mylist:
    print(item)
