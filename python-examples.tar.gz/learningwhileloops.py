# Uhoh, our code ran forever, plus it wasn't that useful...
# while True:
#    print("Python is the coolest!")

# This is a bit more useful, but it ran forever too!
# count_down = 10
# while count_down > 0:
#    print(f"COUNT DOWN = {count_down}")

count_down = 10
while count_down > 0:
    print(f"COUNT DOWN = {count_down}")
    count_down -= 1
